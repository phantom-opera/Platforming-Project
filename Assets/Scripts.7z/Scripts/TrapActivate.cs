﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrapActivate : MonoBehaviour
{
	public AudioSource trapSound;

	[SerializeField] private Transform player;
	[SerializeField] private Transform respawnPoint;
	private bool collisionOccurred = false;
	Animator animator;

	void Start()
	{
		animator = GetComponent<Animator>();
	}


	private void OnTriggerEnter(Collider collision)
	{
		if (collision.tag == "Player" && !collisionOccurred)
		{
			trapSound.Play();
			StartCoroutine(trapActivated());
		}
		collisionOccurred = false;

	}

	IEnumerator trapActivated()
	{
		animator.SetBool("isActivated", true);
		HealthSystem.health--;
		GameObject.Find("First Person Player").GetComponent<PlayerMovement>().enabled = false;
		yield return new WaitForSeconds(2);
		animator.SetBool("isActivated", false);
		player.transform.position = respawnPoint.transform.position;
		GameObject.Find("First Person Player").GetComponent<PlayerMovement>().enabled = true;
	}
	

}
